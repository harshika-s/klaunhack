import pandas as pd

def load_data():
    care_areas = pd.read_csv('CareAreas.csv')
    metadata = pd.read_csv('metadata.csv')
    main_fields = pd.read_csv('MainFields.csv')
    sub_fields = pd.read_csv('SubFields.csv')
    
    return care_areas, metadata, main_fields, sub_fields

def place_main_fields(care_areas, main_field_size):
    main_field_side = main_field_size
    placed_fields = []

    for _, row in care_areas.iterrows():
        x1, x2, y1, y2 = row['x1'], row['x2'], row['y1'], row['y2']
        for i in range(int(x1), int(x2), main_field_side):
            for j in range(int(y1), int(y2), main_field_side):
                main_field = (i, j, i + main_field_side, j + main_field_side)
                placed_fields.append(main_field)
                
    return placed_fields

def place_sub_fields(main_fields, sub_field_size):
    sub_field_side = sub_field_size
    subfield_placements = {}

    for (mf_x1, mf_y1, mf_x2, mf_y2) in main_fields:
        subfields = []
        for y in range(int(mf_y1), int(mf_y2), sub_field_side):
            for x in range(int(mf_x1), int(mf_x2), sub_field_side):
                if x + sub_field_side <= mf_x2 and y + sub_field_side <= mf_y2:
                    subfields.append((x, y))
        subfield_placements[(mf_x1, mf_y1, mf_x2, mf_y2)] = subfields

    return subfield_placements

def format_output(main_fields, sub_fields):

    print("Main Fields:")
    print(main_fields.to_string(index=False))
    print()


    print("Sub-fields with Main Field ID:")
    merged_df = pd.merge(sub_fields, main_fields, left_on='MF_ID', right_on='ID', suffixes=('_SubField', '_MainField'))
    merged_df = merged_df[['ID_SubField', 'x1_SubField', 'x2_SubField', 'y1_SubField', 'y2_SubField', 'MF_ID']]
    merged_df.columns = ['ID', 'x1', 'x2', 'y1', 'y2', 'MF_ID']
    print(merged_df.to_string(index=False))

if __name__ == "__main__":


    care_areas, metadata, main_fields, sub_fields = load_data()

    main_field_size = int(metadata['Main Field Size'].values[0])
    sub_field_size = int(metadata['Sub Field size'].values[0])

    placed_main_fields = place_main_fields(care_areas, main_field_size)
    

    main_fields_df = pd.DataFrame(placed_main_fields, columns=['x1', 'y1', 'x2', 'y2'])
    main_fields_df.reset_index(drop=True, inplace=True)
    main_fields_df.index.name = 'ID'
    main_fields_df.reset_index(inplace=True)

    subfield_placements = place_sub_fields(placed_main_fields, sub_field_size)

    sub_fields_list = []
    for main_field_id, subfields in enumerate(subfield_placements.values()):
        for (x, y) in subfields:
            sub_fields_list.append([len(sub_fields_list), x, x + sub_field_size, y, y + sub_field_size, main_field_id])

    sub_fields_df = pd.DataFrame(sub_fields_list, columns=['ID', 'x1', 'x2', 'y1', 'y2', 'MF_ID'])


    main_fields_df.to_csv('MainFields.csv', index=False)
    sub_fields_df.to_csv('SubFields.csv', index=False)

    format_output(main_fields_df, sub_fields_df)
